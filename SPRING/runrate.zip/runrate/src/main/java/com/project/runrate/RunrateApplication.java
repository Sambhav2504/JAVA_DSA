package com.project.runrate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RunrateApplication {

	public static void main(String[] args) {
		SpringApplication.run(RunrateApplication.class, args);
	}

}
