package com.project.runrate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RunrateApplicationTests {

	@Test
	void contextLoads() {
	}

}
